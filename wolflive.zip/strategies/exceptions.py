
class StopBot(Exception):
    """exception to interrupt bot
    """
    message = "Full bot interupt"

class StopBotError(Exception):
    """exception to interrupt bot
    """
    message = "Full bot interupt"
    