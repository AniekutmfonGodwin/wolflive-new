# %%
# from jockey_bot import Jockey_Bot
from jockey_bot_v2 import Jockey_Bot_v2


# %%
username_1 = "jeremy.trac@appzily.com"
password_1 = "951753"
self = Jockey_Bot_v2(username_1,password_1)
# %%
self.login()

# %%
