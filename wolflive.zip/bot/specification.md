## autoplay can be done for all the category and game
    !cd autoplay
    !gap autoplay
    !scramble autoplay
    !typing autoplay
    !backwards autoplay
    !math autoplay
    !gw autoplay
    !gw Logos autoplay
    !gw Close Ups autoplay
    !gw Around The World autoplay
    !gw Mixed autoplay
    !gw Celebrities autoplay
    !gw Sports autoplay
    !gw Food autoplay
    !gw Music autoplay
    !gw Anime autoplay
    !gw Nature autoplay
    !gw 4in1 autoplay
    !gw Shuffled autoplay


<!-- ### if game stop for 1 min restart game -->

<!-- ### i notes sometimes by testing scramble it just stop  -->
<!-- ### playing when i type the command again it starts play ### again -->

<!-- ### save only correct answer -->

<!-- ### bot stand still player plays bot records the answer -->

<!-- ### gw has and error solve it by refreshing the browser -->

<!-- ### database query fast -->

<!-- ### if autoplay doesnt work for a while start game again -->

### bot plays more than one category in guess what 1000 for each turn auto change category


ok 100$ and as long as you gonna make new order i want a timing game bot only that support Arabic and have the option to start a game itself or just solve timing games others start in the room but the bot must be accurate time, not just randomly solve so 2 options:
1- bot type:
1
2
3
!وقت it's !timing in arabic
second option:
i start the bot it waits till someone in the room starts a game and solves it.
and ill tip an extra 50$ too so all 150$

<!-- 
also, gw autoplay need som adjustments it's always skipping the new game after a correct answer and starts a new one -->


