while in the root folder
open the terminal and type cd <name of folder>
for our case..

    cd bot

to go to the bot folder


while in the bot folder
just type the game command in the terminal without the keywords


e.g

!cw -> for countdown
!gap -> for fill the gap and so open


after typing the command, wait for the bot to login. After login you will be prompt to choose between autoplay (yes/no)
if autoplay is set the bot will play the game in auto else you will be prompt to set the amount of times the bot should play the game


note
!all -> for all the games


available games:
!cd
!gap
!nd
!scramble
!taboo
!timing
!typing
!backwards
!math
!quiz_private
!gw
!all

games that has bot command:
!gw
!gap
!timing




new requiements:
django






