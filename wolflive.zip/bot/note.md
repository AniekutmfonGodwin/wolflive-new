## autoplay can be done for all the category and game
    !cd autoplay
    !gap autoplay
    !scramble autoplay
    !typing autoplay
    !backwards autoplay
    !math autoplay
    !gw autoplay
    !gw Logos autoplay
    !gw Close Ups autoplay
    !gw Around The World autoplay
    !gw Mixed autoplay
    !gw Celebrities autoplay
    !gw Sports autoplay
    !gw Food autoplay
    !gw Music autoplay
    !gw Anime autoplay
    !gw Nature autoplay
    !gw 4in1 autoplay
    !gw Shuffled autoplay

### also can you make the bot detect if the game stopped ### for like 1 min to start the game again




### i notes sometimes by testing scramble it just stop ### playing when i type the command again it starts play ### again


anies can you make gw bot saves the correct answers i type in the room it will be faster this way to build a database so if you can do this it will be great


or make the bot just stand still i play and it records all the images with the correct answers


i found a fix for the gw error make it refresh the browser if it gets error message it will start play again can you add this to all the games please

nd working fine i only got the issue with gw sometimes it say field under !gw scrambled but i refresh the browser and it start working


gm anies im gonna need more ppl to help me with gw database can you please make the bot records the correct answers if someone type it in the room it well be easier for me also the refresh thing if the bot get error messages also if you can do it for gap bot to record the right answers too.


i mean from the room like gw if someone type it and the autoplay for gw don't work it skips the next auto photo and type the gw command


hello anies can you make the bot play more than one category with a number like play 1000 anime finish play 1000 sport etc.


simple category with gap not gw in gap you only need one but gw you have to solve all of them to get the achievement i ask for all of them in the order details
2- solve guess what bot categories all of them but i can but 1 or more categories for the bot to solve with an option to solve 1000 correct photos then go to the next category till it's done all of them.

also, make a separate database file for each category cus the bot now takes to long to find the answer after the database got bigger and sometimes get answers from another category


ok 100$ and as long as you gonna make new order i want a timing game bot only that support Arabic and have the option to start a game itself or just solve timing games others start in the room but the bot must be accurate time, not just randomly solve so 2 options:
1- bot type:
1
2
3
!وقت it's !timing in arabic
second option:
i start the bot it waits till someone in the room starts a game and solves it.
and ill tip an extra 50$ too so all 150$


timing bot orders in arabic
!وقت = !timing
الان = now

can you make gw have a learning mod i mean saves the correct answers, anyone type in the room this will be much better than typing it in the database one by one


also, gw autoplay need som adjustments it's always skipping the new game after a correct answer and starts a new one