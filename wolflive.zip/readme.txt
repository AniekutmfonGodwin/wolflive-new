commands to start bot

the same commands used in the game
!h -> hangman
!decipher
!jockey


the rest of the four game can be played with 

!four_bot



the config.ini file contain settings for each of the bot and also 
for the general settings

if you dont want a game to play set "play" to no or keep it blank like this

    play =



